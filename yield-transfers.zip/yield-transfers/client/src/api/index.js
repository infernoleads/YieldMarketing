// client/src/api/index.js
// Resource-oriented API surface used by the pages/components.
import { api, setToken } from "./client.js";

export const authApi = {
  login: (email, password) => api.post("/auth/login", { email, password }),
  register: (payload) => api.post("/auth/register", payload),
  me: () => api.get("/auth/me"),
  logout: () => setToken(null),
};

export const leadsApi = {
  list: (params) => api.get("/leads", params),
  get: (id) => api.get(`/leads/${id}`),
  create: (payload) => api.post("/leads", payload),
  update: (id, payload) => api.patch(`/leads/${id}`, payload),
  remove: (id) => api.del(`/leads/${id}`),
};

export const agenciesApi = {
  list: () => api.get("/agencies"),
  get: (id) => api.get(`/agencies/${id}`),
  create: (payload) => api.post("/agencies", payload),
  update: (id, payload) => api.patch(`/agencies/${id}`, payload),
};

export const usersApi = {
  list: () => api.get("/users"),
  invite: (payload) => api.post("/users/invite", payload),
  update: (id, payload) => api.patch(`/users/${id}`, payload),
  remove: (id) => api.del(`/users/${id}`),
};

export const tasksApi = {
  list: (params) => api.get("/tasks", params),
  create: (payload) => api.post("/tasks", payload),
  update: (id, payload) => api.patch(`/tasks/${id}`, payload),
  remove: (id) => api.del(`/tasks/${id}`),
};

export const appointmentsApi = {
  create: (payload) => api.post("/appointments", payload), // public
  list: () => api.get("/appointments"),
  update: (id, payload) => api.patch(`/appointments/${id}`, payload),
};

export const assignmentsApi = {
  list: () => api.get("/assignments"),
  create: (payload) => api.post("/assignments", payload),
  update: (id, payload) => api.patch(`/assignments/${id}`, payload),
};

export const messagesApi = {
  list: (conversationId) => api.get("/messages", { conversationId }),
  create: (payload) => api.post("/messages", payload),
};

export const reportsApi = {
  dashboard: () => api.get("/reports/dashboard"),
  agency: (id) => api.get(`/reports/agency/${id}`),
  listScheduled: () => api.get("/reports/scheduled"),
  createScheduled: (payload) => api.post("/reports/scheduled", payload),
  sendScheduledNow: (id) => api.post(`/reports/scheduled/${id}/send`, {}),
  removeScheduled: (id) => api.del(`/reports/scheduled/${id}`),
};
