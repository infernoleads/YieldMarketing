// client/src/hooks/index.js
import { useEffect, useState } from "react";

// Debounce a rapidly-changing value (e.g. a search box).
export function useDebounce(value, delay = 300) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

// Set the document title for a page.
export function useDocumentTitle(title) {
  useEffect(() => {
    const prev = document.title;
    document.title = title ? `${title} · Yield Transfers` : "Yield Transfers";
    return () => { document.title = prev; };
  }, [title]);
}
